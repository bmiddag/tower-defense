#include "gui.h"
#include "world.h"
#include "game.h"
#include "hud.h"
#include "render.h"

void render_world_to_sprite(World * world) 
{

}

void render_world(World * world)
{

}

void render_spellscreen(Spells * spells)
{

}

void render_entity(Entity *entity)
{

}

void render_projectiles(Entity * tower)
{

}

void render_ui(GameState * state)
{
	/* UI background */

	/* Buttons */
	render_buttons(&state->hud);

	/* HUD */
}

void render_hud(Hud * hud)
{

}

void render_game_over(GameState * state)
{

}

void render_mouse_actions(GameState * state)
{

}



/* === Implemented methods, DO NOT CHANGE === */

void render_paths(GameState * state)
{
	Path * path;
	Color red = {255, 0, 0, 255};
	Color orange = {255, 192, 0, 255};
	int i,j, x = 0, y = 0, prev_x = 0, prev_y = 0;
	float scale = 0.2;

	for (i = 0; i < state->enemies_length; i++) {
		path = &state->enemies[i].enemy.path;
		for (j = 0; j < path->length; j++) {
			prev_x = x;
			prev_y = y;
			x = convert_tile2screen_x(path->nodes[j].tile_x) + 0.5*TILE_SIZE;
			y = convert_tile2screen_y(path->nodes[j].tile_y) + 0.5*TILE_SIZE;

			if (j != 0) {
				draw_line(red, prev_x, prev_y, x, y, 2.0);
			}
			if (j == 0 || j == (path->length - 1)) {
				draw_rectangle(x-(TILE_SIZE*scale),y-(TILE_SIZE*scale), x+(TILE_SIZE*scale), y+(TILE_SIZE*scale), red);
			} else if (j == path->current_node_index) {
				draw_triangle(x, y-TILE_SIZE*(scale+0.1), x-TILE_SIZE*(scale+0.1), y+TILE_SIZE*(scale+0.1), x+TILE_SIZE*(scale+0.1), y+TILE_SIZE*(scale+0.1), red);
				draw_triangle(x, y-TILE_SIZE*scale, x-TILE_SIZE*scale, y+TILE_SIZE*(scale+0.05), x+TILE_SIZE*scale, y+TILE_SIZE*(scale+0.05), orange);
			} else {
				draw_circle(x, y, scale*TILE_SIZE, red);
			}

		}
	}
}
