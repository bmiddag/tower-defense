#include "entities.h"
#include "world.h"

void init_world(World * world, int width_in_tiles, int height_in_tiles)
{

}

void init_world_from_file(World * world, char * worldFileName)
{
	
}

Entity * place_tower(World * world, TowerType type, float world_x, float world_y)
{
	
}

void destroy_tower(World * world, Entity * tower)
{

}

void destroy_world(World * world)
{

}