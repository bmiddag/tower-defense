#include <stdlib.h>
#include "entities.h"
#include "world.h"
#include "util.h"
#include "pathfinding.h"
#include "config.h"
#include "priority_queue.h"
#include "hash_set.h"
#include <math.h>
#include <stdio.h>

#define DEFAULT_MOVE_COST 10;

/* Useful definitions for neighbour calculation */
#define NR_OF_DIRECTIONS 4
typedef enum {UP, DOWN, LEFT, RIGHT} Directions;
const int x_movement[NR_OF_DIRECTIONS] = {0, 0, -1, 1};
const int y_movement[NR_OF_DIRECTIONS] = {1, -1, 0, 0}; 

/* Private function */
int find_path(World * world, Node * start, Node * goal, Node ** path_array, TrajectoryType trajectory_type)
{
	
}


int create_path(Path * path, World * world, Entity * from, Entity * to, TrajectoryType trajectory_type) 
{

}

int refresh_path(Path * path, World * world)
{
	
}

void destroy_path(Path * path)
{
	
}
