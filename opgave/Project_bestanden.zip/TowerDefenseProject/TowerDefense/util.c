#include "config.h"
#include "util.h"

float convert_world2screen_x(float world_x)
{

}

float convert_world2screen_y(float world_y)
{

}

float convert_tile2screen_x(float tile_x)
{

}

float convert_tile2screen_y(float tile_y)
{

}

float convert_tile2world_x(int tile_x)
{

}

float convert_tile2world_y(int tile_y)
{

}

float convert_screen2world_x(float screen_x)
{

}
float convert_screen2world_y(float screen_y)
{

}

int convert_screen2tile_x(float screen_x)
{

}

int convert_screen2tile_y(float screen_y)
{

}

int convert_world2tile_x(float world_x)
{

}

int convert_world2tile_y(float world_y)
{

}


float euclidean_distance(float x1, float y1, float x2, float y2)
{

}

float find_alpha(float horizontal_length, float vertical_length, float diagonal_length)
{
	
}

void dissolve_speed(float alpha_radians, float speed, float * horizontal, float * vertical)
{
	
}

void calc_direction(float from_x, float from_y, float to_x, float to_y, int * direction_x, int * direction_y)
{
	
}

float find_render_angle(float alpha_radians, int direction_x, int direction_y)
{
	
}




/* === Already implemented, DO NOT CHANGE */

int in_world_screen(float screen_x, float screen_y)
{
	return (screen_x >= SCREEN_START_X && screen_x <= SCREEN_WIDTH &&
		screen_y >= SCREEN_START_Y && screen_y <= SCREEN_HEIGHT);
}