#include <stdlib.h>
#include "entities.h"
#include "config.h"


void init_entity(Entity * entity, EntityType type, int world_x, int world_y, int width, int height)
{
	
}

int is_colliding(Entity * e1, Entity * e2)
{
	
}

void init_tower_blueprint(Entity * entity, TowerType tower_type)
{
	
}

void init_machine_gun(Entity * entity, float world_x, float world_y)
{
	
}

void init_rocket_launcher(Entity * entity, float world_x, float world_y)
{
	
}

void init_flak_cannon(Entity * entity, float world_x, float world_y)
{
	
}

void init_enemy(Entity * enemy, EnemyType type)
{
	
}

/* === Implemented functions, DO NOT CHANGE! */

void init_frameAnimator(FrameAnimator * animator, int animationColumns, int maxFrame, int frameDelay, int frameHeight, int frameWidth)
{
	animator->animationColumns = animationColumns;
	animator->animationDirection = 1;
	animator->curFrame = 0;
	animator->frameCounter = 0;
	animator->frameDelay = frameDelay;
	animator->frameHeight = frameHeight;
	animator->frameWidth =  frameWidth;
	animator->maxFrame = maxFrame;
}