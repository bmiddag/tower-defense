#include "entities.h"
#include "tower_ai.h"
#include "world.h"

int is_valid_target(Tower * t, Enemy * e)
{

}

Enemy * find_target(Tower * t, Entity * enemies, int enemies_length)
{
	
}

void shoot(Tower * t)
{
	
}

int is_out_of_range(Projectile * p, Tower * t, World * w)
{
	
}

void do_damage(Projectile * p, Enemy * e)
{
	
}