#include <stdio.h>
#include <stdlib.h>
#include "config.h"
#include "world.h"
#include "gui.h"
#include "render.h"
#include "pathfinding.h"
#include "entities.h"
#include "util.h"
#include "game.h"
#include "tower_ai.h"

/* === Prototypes === */
void set_button_hover_state(GameState * state);
void set_button_action(GameState * state);
void reset_button_action(GameState * state);
void reset_all_buttons_action(GameState * state);


int run_game_loop(GameState * state)
{
	int done = 0;
	int i = 0;
	
	/* Initialise gui */
	init_gui(SCREEN_WIDTH,SCREEN_HEIGHT);

	/* Load resources */
	init_sprite_cache();
	render_world_to_sprite(&state->world);
	update_hud(
		&state->hud, 
		&state->score,
		&state->mana,
		&state->money, 
		&state->world.castle->castle.health,
		&state->wave.wave_number);

	/* Initialise game loop */
	init_game_loop(FPS);
	while (!done)
	{
		/* Get events */
		Event ev;
		wait_for_event(&ev);

		/* Event handlers */
		switch (ev.type) {
			case EVENT_TIMER:
				state->redraw = 1;
				if(!state->game_over) {
					check_spells(state);
					check_enemy_wave(state);
					update_movement(state);
					do_tower_attacks(state);
				}
				break;
			case EVENT_MOUSE_MOVE:
				mouse_move(&ev.mouseMoveEvent, state);
				break;
			case EVENT_MOUSE_DOWN:
				mouse_down(&ev.mouseDownEvent, state);
				break;
			case EVENT_MOUSE_UP:
				mouse_up(&ev.mouseUpEvent, state);
				break;
			case EVENT_DISPLAY_CLOSE:
				done = 1;
				break;
		}	

		/* Render only on timer event AND if all movement and logic was processed */
		if (state->redraw && all_events_processed()) { 
			render_game(state);
		}
	}

	/* Cleanup */
	cleanup_game_loop();
	cleanup_sprite_cache();
	return 0;
}

void check_spells(GameState * state) {
	
}

void check_enemy_wave(GameState * state)
{
	
}

void update_movement(GameState * state) {
	
}

void do_tower_attacks(GameState * state)
{
	
}

void init_game_state(GameState * state)
{

	/* Initialise Buttons */
	init_buttons(&state->hud);
}

void destroy_game_state(GameState * state)
{
	
}

void render_game(GameState * state)
{
	/* Variables */
	Color color = {255, 0, 255, 255};
	Color black = {0, 0, 0, 255};
	Color white = {255, 255, 255, 255};
	char buffer [20];
	int i,n;

	/* Set redraw off */
	state->redraw = 0;

	/* Render world */
	render_world(&state->world);

	/* Render pathfinding, if enabled */
	if (SHOW_PATHFINDING)
		render_paths(state);
	
	/* Render towers */
	for(i = 0; i < state->towers_length; i++) {
		render_entity(state->towers[i]);
	}
	
	/* Render enemies if they are alive */
	for(i = 0; i < state->enemies_length; i++) {
		if(state->enemies[i].enemy.alive)
			render_entity(&state->enemies[i]);
	}

	/* Render spellscreen */
	render_spellscreen(&state->spells);

	/* Render projectiles */
	for(i = 0; i < state->towers_length; i++) {
		render_projectiles(state->towers[i]);
	}

	
	/* render selection */
	render_mouse_actions(state);

	/* Render ui on top */
	render_ui(state);

	/* Fps rendering */
	n = sprintf(buffer, "%#.1f FPS", get_current_fps());
	draw_text(buffer, FONT_LARGE, color, SCREEN_WIDTH-20 -100, 6, ALIGN_RIGHT);

	/* Game over? */
	render_game_over(state);

	/* Render to screen */
	flip_display();
	clear_to_color(color);
}

void update_mouse(GameState * state, float screen_x, float screen_y)
{
	Mouse * mouse = &state->mouse;
	int prev_tile_x = mouse->tile_x;
	int prev_tile_y = mouse->tile_y;
	
	mouse->screen_x = screen_x;
	mouse->screen_y = screen_y;
	mouse->world_x = convert_screen2world_x(screen_x);
	mouse->world_y = convert_screen2world_y(screen_y);
	mouse->tile_x = convert_screen2tile_x(screen_x);
	mouse->tile_y = convert_screen2tile_y(screen_y);
	
	mouse->tile_changed |= (mouse->tile_x != prev_tile_x) || (mouse->tile_y != prev_tile_y);
}


/* === Event handlers === */

void mouse_move(MouseMoveEvent * ev, GameState * state)
{
	Mouse * mouse = &state->mouse;
	
	/* Update mouse pointer location */
	update_mouse(state, ev->screen_x, ev->screen_y);

	if (in_world_screen(mouse->screen_x, mouse->screen_y)) {
		/* IMPLEMENT HERE*/
		
		/* Already implemented code to reset buttons after hovering. DO NOT CHANGE */
		reset_all_buttons_action(state);
	}
	
	else { /* Outside of world frame => buttons */
		set_button_hover_state(state); /* DO NOT CHANGE */
	}
}

void mouse_down(MouseDownEvent * ev, GameState * state)
{
	if (ev->button == 1) {
		Mouse * mouse = &state->mouse;
		int i;

		if (in_world_screen(mouse->screen_x, mouse->screen_y)) {
			/* IMPLEMENT */
		}
		else { /* Outside of world frame => buttons */
			set_button_action(state); /* DO NOT CHANGE */
		}
	}
	else if (ev->button == 2) {
		state->action = NONE;
	}
}

void mouse_up(MouseUpEvent * ev, GameState * state)
{
	reset_button_action(state);
}


/* === Implemented methods, DO NOT CHANGE === */

void set_button_hover_state(GameState * state)
{
	int i;
	Button * buttons = state->hud.buttons;
	Mouse * mouse = &state->mouse;

	for (i = 0; i < BUTTON_AMOUNT; i++) {
		if (in_bounds(mouse->screen_x, mouse->screen_y, buttons[i].bounds)) {
			buttons[i].state = BUTTON_HOVER;
		} 
		else {
			buttons[i].state = BUTTON_UP;
		}
	}
}

void set_button_action(GameState * state)
{
	int i;
	Button * buttons = state->hud.buttons;
	Mouse * mouse = &state->mouse;

	for (i = 0; i < BUTTON_AMOUNT; i++) {
		if (in_bounds(mouse->screen_x, mouse->screen_y, buttons[i].bounds)) {
			buttons[i].state = BUTTON_DOWN;
			switch(i) {
			case BUTTON_TOWER_MACHINEGUN:
				init_tower_blueprint(&state->blueprint.entity, MACHINE_GUN);
				state->action = BUILD_TOWER;
				break;

			case BUTTON_TOWER_ROCKET:
				init_tower_blueprint(&state->blueprint.entity, ROCKET_LAUNCHER);
				state->action = BUILD_TOWER;
				break;

			case BUTTON_TOWER_FLAK:
				init_tower_blueprint(&state->blueprint.entity, FLAK_CANNON);
				state->action = BUILD_TOWER;
				break;
			case BUTTON_DESTROY_TOWER:

				state->action = DESTROY_TOWER;
				break;
			case BUTTON_SPELL_FREEZE:
				state->action = GENERATE_FROST_WAVE;
				break;

			case BUTTON_SPELL_KILL:
				state->action = RELEASE_POISON_GAS;
				break;
			}
		}
	}
}

void reset_button_action(GameState * state)
{
	Mouse * mouse = &state->mouse;
	Button * buttons = state->hud.buttons;
	int i;

	for (i = 0; i < BUTTON_AMOUNT; i++) {
		if (in_bounds(mouse->screen_x, mouse->screen_y, buttons[i].bounds)) {
			buttons[i].state = BUTTON_UP;
		}
	}
}

void reset_all_buttons_action(GameState * state)
{
	Button * buttons = state->hud.buttons;
	int i;

	for (i = 0; i < BUTTON_AMOUNT; i++)
		buttons[i].state = BUTTON_UP;
}