#include "entities.h"
#include "priority_queue.h"

void pq_init(PriorityQueue * pq)
{

}

void insert_before(PriorityQueue * pq, Element * new_element, Element * target_element)
{
	
}

void insert_after(PriorityQueue * pq, Element * new_element, Element * target_element)
{
	
}

void pq_offer(PriorityQueue * pq, Node * node)
{
	
}

int pq_is_empty(PriorityQueue * pq)
{
	
}

Node * pq_poll(PriorityQueue * pq)
{
	
}

Node * pq_peek(PriorityQueue * pq)
{
	
}

int pq_contains(PriorityQueue * pq, Node * node)
{
	
}

void pq_remove_element(PriorityQueue * pq, Element * element)
{

}

void pq_remove(PriorityQueue * pq, Node * node)
{
	
}

void pq_destroy(PriorityQueue * pq)
{
	
}