#include <stdlib.h>
#include "hash_set.h"

void hs_init(HashSet * hs)
{
	
}

void hs_add(HashSet * hs, Node * node)
{
	
}

int hs_contains(HashSet *hs, Node * node)
{
	
}

void hs_remove_entry(HashEntry** list) {
	
}

void hs_remove(HashSet * hs, Node * node)
{
	
}

Node * hs_get_node(HashSet * hs, int tile_x, int tile_y)
{
	
}

/* Geeft 0 terug als er niet opnieuw gehasht moet worden
   Geeft de nieuwe aantal buckets terug als er wel opnieuw gehasht moet worden 
   Already implemented, do not change!
*/
int rehash_nr_of_buckets(const HashSet* hs) {
	if (hs->size > 8 * hs->nr_of_buckets) {
		return 16 * hs->nr_of_buckets;
	}
	else if (hs->nr_of_buckets > DEFAULT_BUCKETS && hs->nr_of_buckets > 8 * hs->size) {
		return hs->nr_of_buckets / 16;
	}
	return 0;
}

void hs_rehash(HashSet * hs)
{
	
}

unsigned int hs_calc_hash(Node * node)
{
	
}

void hs_destroy(HashSet * hs)
{
	
}